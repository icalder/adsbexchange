#!/usr/bin/perl
# This file was preprocessed, do not edit!


package Debconf::FrontEnd::Text;
use warnings;
use strict;
use base qw(Debconf::FrontEnd::Readline);


1
