#!/usr/bin/perl
# This file was preprocessed, do not edit!


package Debconf::Format;
use warnings;
use strict;
use base qw(Debconf::Base);


1
